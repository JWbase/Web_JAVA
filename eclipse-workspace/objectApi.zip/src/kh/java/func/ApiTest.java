package kh.java.func;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Scanner;

public class ApiTest {
	public void math() {

		//객체를 생성하지않고 바로 사용
		System.out.println(Math.abs(10)); // 절대 값
		System.out.println(Math.abs(-10)); // 절대 값

		//올림, 버림, 반올림
		System.out.println(Math.ceil(10.1)); // 소수 첫자리에서 올림 -> 11
		System.out.println(Math.floor(10.9)); // 소수 첫자리에서 버림
		System.out.println(Math.round(10.5));
		System.out.println(Math.round(10.4));
		//1.3456 -> 소수 3째자리 반올림 1.35
		//1.3456 -> 134.56 -> 135
		System.out.println(Math.round(1.3456 * 100) / (double) 100);
		// 숫자비교
		System.out.println(Math.max(50, 30)); // 매개변수로 전달한 두 수 중 큰 수 리턴
		System.out.println(Math.min(50, 30));
	}

	public void date() {
		Date today = new Date();
		System.out.println(today);
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		String todayStr = format1.format(today);
		System.out.println(todayStr);
		SimpleDateFormat format2 = new SimpleDateFormat("yyyy년MM월dd일 HH시mm분ss초 EEE요일");
		todayStr = format2.format(today);
		System.out.println(todayStr);
	}

	public void calendar() {
		Calendar today = Calendar.getInstance();
		//Calendar 클래스의 생성자의 접근제어지시자가 protect
		//getInstance()메소드를 통해서만 객체 생성이 가능
		//정보가져오는 방법 today.get(정보종류);
		System.out.println(today.get(Calendar.YEAR)); // 년도
		System.out.println(today.get(Calendar.MONTH) + 1); // 월
		System.out.println(today.get(Calendar.DATE)); // 일
		System.out.println(today.get(Calendar.AM_PM));
		System.out.println(today.get(Calendar.HOUR));
		System.out.println(today.get(Calendar.MINUTE));
		System.out.println(today.get(Calendar.SECOND));
		System.out.println(today.get(Calendar.MILLISECOND));
		System.out.println(today.get(Calendar.DAY_OF_WEEK)); //요일
		System.out.println("-----------------------------------------------------------");
		Calendar day1 = Calendar.getInstance();
		System.out.println(day1.get(Calendar.MONTH) + 1);
		System.out.println(day1.get(Calendar.DATE));
		System.out.println(day1.get(Calendar.DAY_OF_WEEK));

		//날짜랑 시간정보 변경
		day1.set(Calendar.MONTH, 10); // 11월
		day1.set(Calendar.DATE, 18);
		System.out.println(day1.get(Calendar.MONTH) + 1);
		System.out.println(day1.get(Calendar.DATE));
		System.out.println(day1.get(Calendar.DAY_OF_WEEK));

		Calendar day2 = Calendar.getInstance();
		long time1 = day2.getTimeInMillis(); // 1960년 1월 1일부터 day2까지 몇 ms가 흘렀는지 리턴
		day2.set(Calendar.DATE, 8);
		long time2 = day2.getTimeInMillis();
		System.out.println("time1 : " + time1);
		System.out.println("time2 : " + time2);
		System.out.println("시간차이 : " + (time2 - time1));

		Date date1 = new Date(time1);
		Date date2 = new Date(time2);
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd HH:MM:ss");
		String date1Str = format.format(date1);
		String date2Str = format.format(date2);
		System.out.println(date1Str);
		System.out.println(date2Str);
	}

	public void exam1() {
		Scanner sc = new Scanner(System.in);

		System.out.println("============= D-DAY 계산기 =============");
		System.out.print("D-DAY [년도] 입력 : ");
		int year = sc.nextInt();
		System.out.print("D-DAY [월] 입력 : ");
		int month = sc.nextInt();
		System.out.print("D-DAY [일] 입력 : ");
		int date = sc.nextInt();

		Date today = new Date();
		SimpleDateFormat format1 = new SimpleDateFormat("yyyy년MM월dd일");
		String todayStr = format1.format(today);
		System.out.println("오늘 날짜 : " + todayStr);

		Calendar day = Calendar.getInstance();
		long time1 = day.getTimeInMillis();
		day = Calendar.getInstance();
		day.set(Calendar.YEAR, year);
		day.set(Calendar.MONTH, month);
		day.set(Calendar.DATE, date);
		long time2 = day.getTimeInMillis();
		System.out.println("D-DAY 날짜 : " + day.get(Calendar.YEAR) + "년" + day.get(Calendar.MONTH) + "월"
				+ day.get(Calendar.DATE) + "일");
	}

}
