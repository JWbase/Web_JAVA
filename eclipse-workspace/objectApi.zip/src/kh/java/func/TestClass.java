package kh.java.func;

public class TestClass implements Cloneable {

//	@Override
//	public String toString() {
//		return "하이";
	
	@Override
	public Object clone() throws CloneNotSupportedException{
		return super.clone();
		

	}

}
