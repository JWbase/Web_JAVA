package kh.java.run;

import kh.java.func.ApiTest;
import kh.java.func.StringClass;
import kh.java.func.TestClass;
import kh.java.lee.Calc;

public class Start {

	public static void main(String[] args) {
		ApiTest sc = new ApiTest();
		sc.exam1();
	}
}