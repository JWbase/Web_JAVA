package kr.or.iei.lecture.vo;

public class CulturalStudies extends SubjectType {

	public CulturalStudies() {
		super();
	}

	public CulturalStudies(String subjectName, int score, String professorName, int room, String day, int startTime,
			String subjectType) {
		super(subjectName, score, professorName, room, day, startTime, subjectType);
	}

}
