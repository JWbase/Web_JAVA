package kr.or.iei.lecture.start;

import kr.or.iei.lecture.controller.LectureControllerImpl;

public class Start {

	public static void main(String[] args) {

		LectureControllerImpl lc = new LectureControllerImpl();
		lc.main();
	}
}