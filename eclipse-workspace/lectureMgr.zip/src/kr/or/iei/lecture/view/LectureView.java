package kr.or.iei.lecture.view;

import java.util.Scanner;

import kr.or.iei.lecture.vo.CulturalStudies;
import kr.or.iei.lecture.vo.Major;
import kr.or.iei.lecture.vo.SubjectType;

public class LectureView {

	Scanner sc;

	public LectureView() {
		super();
		sc = new Scanner(System.in);
	}

	public int showMain() {
		System.out.println("====== 사용자/관리자 선택 =====");
		System.out.println("1. 관리자");
		System.out.println("2. 사용자");
		System.out.println("0. 프로그램 종료");
		System.out.print("선택 > ");
		int sel = sc.nextInt();

		return sel;
	}

	public void exit() {
		System.out.println("프로그램을 종료합니다.");
	}

	public int showMenu() {
		System.out.println("1. 강의 추가하기");
		System.out.println("2. 강의 삭제하기");
		System.out.println("3. 강의 목록 확인하기");
		System.out.println("4. 단일 과목 조회하기");
		System.out.println("0. 종료");
		System.out.print("선택 > ");
		int sel = sc.nextInt();
		return sel;
	}

	public SubjectType insertLecture() {
		System.out.println("============ 강의 추가하기 =============");
		System.out.print("추가할 과목명 입력 : ");
		sc.nextLine();
		String subjectName = sc.nextLine();
		System.out.print("해당하는 과목의 학점 입력(1~3) : ");
		int score = sc.nextInt();
		System.out.print("해당하는 과목의 교수명 입력 : ");
		String professorName = sc.next();
		System.out.print("해당하는 과목의 강의실 입력 : ");
		int room = sc.nextInt();
		System.out.print("해당하는 과목의 수강요일 입력(월,화,수,목,금) : ");
		String day = sc.next();
		System.out.print("해당하는 과목의 시작시간 입력(1~9) : ");
		int startTime = sc.nextInt();
		System.out.print("해당하는 과목의 교양/전공 입력 : ");
		String subjectType = sc.next();

		SubjectType sub = null;
		switch (subjectType) {
		case "전공":
			Major m = new Major(subjectName, score, professorName, room, day, startTime, subjectType);
			sub = (SubjectType) m;
			break;
		case "교양":
			CulturalStudies cul = new CulturalStudies(subjectName, score, professorName, room, day, startTime,
					subjectType);
			sub = (SubjectType) cul;
			break;
		}
		return sub;
	}

	public String deleteLecture() {
		System.out.println("============= 강의 삭제하기 ==============");
		System.out.print("삭제할 강의 이름을 입력해주세요 : ");

		String lectureName = sc.next();
		return lectureName;
	}

	public void deleteComplete() {
		System.out.println("강의 삭제가 완료되었습니다!");
	}

	public void noSearchLecture() {
		System.out.println("강의 정보를 찾을 수 없습니다.");
	}

	public void printAllLecture(SubjectType[] subjects, int index) {
		System.out.println("============ 전체 강의 출력 =============");
		System.out.println("과목명(구분)\t학점\t교수명\t요일\t시작시간");
		for (int i = 0; i < index; i++) {
			SubjectType st = subjects[i];
			System.out.printf("%s(%s)\t%d\t%s\t%s\t%d교시", st.getSubjectName(), st.getSubjectType(), st.getScore(),
					st.getProfessorName(), st.getDay(), st.getStartTime());
			System.out.println();
		}
	}

	public int studentView() {
		System.out.println("====== Student Mod ======");
		System.out.println("1. 전체 시간표 조회");
		System.out.println("2. 수강 신청");
		System.out.println("3. 수강 삭제");
		System.out.println("4. 강의 검색");
		System.out.println("5. 수강신청 확인");
		System.out.println("0. 종료");
		System.out.print("선택 > ");

		int sel = sc.nextInt();
		return sel;
	} // studentView() 종료

	public void printAllClass(SubjectType[] subjects, int index) {
		System.out.println("====== 전체 수업 조회 ======");
		System.out.println("과목명(구분)\t학점\t교수명\t요일\t시작시간");

		for (int i = 0; i < index; i++) {
			SubjectType st = subjects[i];
			System.out.printf("%s(%s)\t%d\t%s\t%s\t%d교시", st.getSubjectName(), st.getSubjectType(), st.getScore(),
					st.getProfessorName(), st.getDay(), st.getStartTime());
			System.out.println();
		}
	} // printAllClass(SubjectType[] subjects, int index)

	public String getName(String str) {

		System.out.println("====== 수강과목 " + str + " ======");
		System.out.print("강의 이름 입력 : ");
		String name = sc.next();

		return name;
	} // getNema(Stirng str) end

	public void findLecture(int searchIndex, SubjectType[] subjects) {

		SubjectType sType = subjects[searchIndex];
		System.out.println("교양 / 전공 : " + sType.getSubjectType());
		System.out.println("강의 이름 : " + sType.getSubjectName());
		System.out.println("교수 이름 : " + sType.getProfessorName());
		System.out.println("학점 : " + sType.getScore());
		System.out.println("강의실 호 수 : " + sType.getRoom());
		System.out.println("요일 : " + sType.getDay());
		System.out.println("시작 시간 : " + sType.getStartTime());
	} // end findLecture(int searchIndex, SubjectTpye[] subjects) end

	public void fault() {
		System.out.println("잘못 입력하셨습니다.");
	}

	// 학생용 뷰

	public String insertLectureStudent() {
		System.out.print("등록할 과목명을 입력하세요 : ");
		String subjectName = sc.next();

		return subjectName;
	}

}