package kh.or.student.start;

import kh.or.student.controller.StudentController;

public class Start {
	public static void main(String[] args) {
		StudentController sc = new StudentController();
		sc.main();
	}
}