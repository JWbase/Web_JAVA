package kr.or.iei.point.start;

import kr.or.iei.point.controller.PointController;

public class Start {

	public static void main(String[] args) {
		
		PointController pc = new PointController();
		
		pc.main();

	}

}
