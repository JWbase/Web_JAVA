package kh.java.run;

import kh.java.func.ListTest;
import kh.java.func.MapTest;
import kh.java.func.SetTest;

public class Start {

	public static void main(String[] args) {
		
		MapTest mt = new MapTest();
		
		mt.mapTest2();

	}

}
