package kr.or.iei.lecture.vo;

public class Major extends SubjectType {

	public Major() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Major(String subjectName, int score, String professorName, int room, String day, int startTime,
			String subjectType) {
		super(subjectName, score, professorName, room, day, startTime, subjectType);
		// TODO Auto-generated constructor stub
	}

}
